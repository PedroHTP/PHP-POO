<?php

namespace App\Model;

class ProdutoDao {

    public function create(Produto $p) {
        
        $comando = "INSERT INTO produtos (nome, descricao) VALUES (?,?)";
    }

    public function read() {

    }

    public function update(Produto $p) {

    }
    
    public function delete(Produto $p) {

    }
}