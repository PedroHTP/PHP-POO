<?php 
// SETS
require_once __DIR__ . '/vendor/autoload.php';

use app\model\ProdutoDao;
use app\model\Produto;

$produto = new \app\model\Produto();
$produto->setNome('Notebook Dell');
$produto->setDescricao('i5, 4gb');

$produtoDao = new \app\model\ProdutoDao();
$produtoDao -> create($produto);

?>
